# Student Attendance Tracker

A simple working prototype based on the provided problem statement.

## Features
- Admin, Faculty and Student login
- Admin can add students and subjects and assign faculty
- Faculty can mark daily attendance using a checklist
- Automatic subject-wise and overall attendance percentage
- Warning when attendance falls below 75%
- Faculty class-wise attendance report
- Responsive UI
- Uses browser localStorage, so no database/server is required for this prototype

## Demo Login
- Admin: admin@college.com / admin123
- Faculty: faculty@college.com / faculty123
- Student: student@college.com / student123

## Run
1. Extract the ZIP.
2. Open `index.html` in a browser.
3. For VS Code, install Live Server if desired and open `index.html` with Live Server.

## Reset demo data
Open browser DevTools Console and run:
localStorage.removeItem("attendance_tracker_v1");
localStorage.removeItem("attendance_session");
location.reload();

## Production upgrade
For a real college deployment, replace localStorage authentication/data with a backend API and database such as FastAPI/Node.js + MySQL/PostgreSQL, hash passwords, add role-based authorization, and use server-side attendance validation.
