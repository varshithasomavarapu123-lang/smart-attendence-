const STORAGE_KEY="attendance_tracker_v1";

const seed={
  users:[
    {id:"A1",name:"Admin User",email:"admin@college.com",password:"admin123",role:"admin"},
    {id:"F1",name:"Dr. Priya",email:"faculty@college.com",password:"faculty123",role:"faculty"},
    {id:"S1",name:"Varshini",email:"student@college.com",password:"student123",role:"student"}
  ],
  subjects:[
    {id:"SUB1",name:"Artificial Intelligence",code:"AI101",facultyId:"F1",className:"B.Tech AI - II Year"},
    {id:"SUB2",name:"Database Management Systems",code:"DBMS201",facultyId:"F1",className:"B.Tech AI - II Year"},
    {id:"SUB3",name:"Java Programming",code:"JAVA202",facultyId:"F1",className:"B.Tech AI - II Year"}
  ],
  students:[
    {id:"S1",name:"Varshini",roll:"AI001",className:"B.Tech AI - II Year"},
    {id:"S2",name:"Harika",roll:"AI002",className:"B.Tech AI - II Year"},
    {id:"S3",name:"Keerthi",roll:"AI003",className:"B.Tech AI - II Year"},
    {id:"S4",name:"Anusha",roll:"AI004",className:"B.Tech AI - II Year"},
    {id:"S5",name:"Divya",roll:"AI005",className:"B.Tech AI - II Year"}
  ],
  attendance:[
    {date:"2026-10-01",subjectId:"SUB1",studentId:"S1",present:true},
    {date:"2026-10-01",subjectId:"SUB1",studentId:"S2",present:true},
    {date:"2026-10-01",subjectId:"SUB1",studentId:"S3",present:false},
    {date:"2026-10-01",subjectId:"SUB1",studentId:"S4",present:true},
    {date:"2026-10-01",subjectId:"SUB1",studentId:"S5",present:false},
    {date:"2026-10-02",subjectId:"SUB1",studentId:"S1",present:true},
    {date:"2026-10-02",subjectId:"SUB1",studentId:"S2",present:true},
    {date:"2026-10-02",subjectId:"SUB1",studentId:"S3",present:false},
    {date:"2026-10-02",subjectId:"SUB1",studentId:"S4",present:true},
    {date:"2026-10-02",subjectId:"SUB1",studentId:"S5",present:true}
  ]
};

function getDB(){return JSON.parse(localStorage.getItem(STORAGE_KEY)||JSON.stringify(seed))}
function saveDB(db){localStorage.setItem(STORAGE_KEY,JSON.stringify(db))}
function uid(prefix){return prefix+Math.random().toString(36).slice(2,8).toUpperCase()}
function today(){return new Date().toISOString().slice(0,10)}
function pct(db,studentId,subjectId){
  const a=db.attendance.filter(x=>x.studentId===studentId && x.subjectId===subjectId);
  if(!a.length)return 0;
  return Math.round(a.filter(x=>x.present).length/a.length*100);
}
function overall(db,studentId){
  const a=db.attendance.filter(x=>x.studentId===studentId);
  if(!a.length)return 0;
  return Math.round(a.filter(x=>x.present).length/a.length*100);
}
function esc(v){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}

let session=JSON.parse(localStorage.getItem("attendance_session")||"null");

function login(){
  const email=document.querySelector("#email").value.trim();
  const password=document.querySelector("#password").value;
  const db=getDB();
  const u=db.users.find(x=>x.email===email&&x.password===password);
  document.querySelector("#loginError").textContent=u?"":"Invalid email or password";
  if(u){session=u;localStorage.setItem("attendance_session",JSON.stringify(u));render()}
}

function logout(){session=null;localStorage.removeItem("attendance_session");render()}

function loginPage(){
  return `<div class="login-page"><div class="login-card">
    <h1>Student Attendance Tracker</h1>
    <p>Simple attendance management for colleges</p>
    <div class="field"><label>Email</label><input id="email" value="student@college.com" placeholder="Enter email"></div>
    <div class="field"><label>Password</label><input id="password" type="password" value="student123" placeholder="Enter password"></div>
    <div id="loginError" class="error"></div>
    <button class="primary" style="width:100%" onclick="login()">Login</button>
    <div class="demo"><b>Demo accounts</b><br>Admin: admin@college.com / admin123<br>Faculty: faculty@college.com / faculty123<br>Student: student@college.com / student123</div>
  </div></div>`
}

function shell(content,active){
  const role=session.role;
  let nav= role==="student"
    ? [["dashboard","Dashboard"],["attendance","My Attendance"]]
    : role==="faculty"
    ? [["dashboard","Dashboard"],["mark","Mark Attendance"],["reports","Class Report"]]
    : [["dashboard","Dashboard"],["subjects","Subjects"],["users","Users"]];
  return `<div class="app"><header class="topbar"><div class="brand">📊 Student Attendance Tracker</div>
    <div class="userbox"><span>${esc(session.name)}</span><span class="role-pill">${role.toUpperCase()}</span><button class="logout" onclick="logout()">Logout</button></div></header>
    <div class="layout"><aside class="sidebar">${nav.map(n=>`<button class="nav-btn ${active===n[0]?"active":""}" onclick="navigate('${n[0]}')">${n[1]}</button>`).join("")}</aside>
    <main class="content">${content}</main></div></div>`
}

function navigate(page){location.hash=page;render()}

function dashboard(){
  const db=getDB();
  if(session.role==="student") return studentDashboard(db);
  if(session.role==="faculty") return facultyDashboard(db);
  return adminDashboard(db);
}

function studentDashboard(db){
  const me=db.students.find(s=>s.id===session.id);
  const rows=db.subjects.map(s=>({s,p:pct(db,me.id,s.id)}));
  const op=overall(db,me.id);
  return `<h1 class="page-title">Welcome, ${esc(me?.name||session.name)} 👋</h1><p class="subtitle">Your attendance overview</p>
    ${op<75?`<div class="warning">⚠️ <b>Attendance Warning:</b> Your overall attendance is ${op}%. Please improve your attendance.</div>`:""}
    <div class="cards"><div class="card"><span class="muted">Overall Attendance</span><div class="stat ${op<75?"red":"green"}">${op}%</div></div>
    <div class="card"><span class="muted">Subjects</span><div class="stat blue">${rows.length}</div></div>
    <div class="card"><span class="muted">Required Limit</span><div class="stat">75%</div></div></div>
    <div class="panel"><h3>Subject-wise Attendance</h3>${rows.length?`<div class="table-wrap"><table><tr><th>Subject</th><th>Code</th><th>Attendance</th><th>Status</th></tr>${rows.map(x=>`<tr><td>${esc(x.s.name)}</td><td>${x.s.code}</td><td><div class="progress"><div style="width:${x.p}%"></div></div><b>${x.p}%</b></td><td><span class="badge ${x.p<75?"low":"ok"}">${x.p<75?"Low Attendance":"Safe"}</span></td></tr>`).join("")}</table></div>`:`<div class="empty">No subjects assigned.</div>`}</div>`
}

function facultyDashboard(db){
  const subs=db.subjects.filter(s=>s.facultyId===session.id);
  const total=db.students.length;
  const todayRecords=db.attendance.filter(a=>a.date===today()&&subs.some(s=>s.id===a.subjectId));
  const present=todayRecords.filter(a=>a.present).length;
  return `<h1 class="page-title">Faculty Dashboard</h1><p class="subtitle">Manage daily attendance and view reports</p>
  <div class="cards"><div class="card"><span class="muted">Assigned Subjects</span><div class="stat blue">${subs.length}</div></div>
  <div class="card"><span class="muted">Students</span><div class="stat">${total}</div></div>
  <div class="card"><span class="muted">Today's Present Records</span><div class="stat green">${present}</div></div></div>
  <div class="panel"><h3>Quick Actions</h3><button class="primary" onclick="navigate('mark')">Mark Today's Attendance</button> <button class="secondary" onclick="navigate('reports')">View Class Report</button></div>`
}

function adminDashboard(db){
  return `<h1 class="page-title">Admin Dashboard</h1><p class="subtitle">Manage the attendance system</p>
  <div class="cards"><div class="card"><span class="muted">Students</span><div class="stat blue">${db.students.length}</div></div>
  <div class="card"><span class="muted">Faculty</span><div class="stat">${db.users.filter(u=>u.role==="faculty").length}</div></div>
  <div class="card"><span class="muted">Subjects</span><div class="stat">${db.subjects.length}</div></div>
  <div class="card"><span class="muted">Low Attendance</span><div class="stat red">${db.students.filter(s=>overall(db,s.id)<75).length}</div></div></div>
  <div class="panel"><h3>System Features</h3><p class="muted">Add subjects, manage users, assign faculty and monitor attendance from the navigation menu.</p></div>`
}

function markAttendance(){
  const db=getDB();
  const subs=db.subjects.filter(s=>s.facultyId===session.id);
  const selected=document.querySelector("#subjectSelect")?.value||subs[0]?.id;
  const date=document.querySelector("#attDate")?.value||today();
  const sub=db.subjects.find(s=>s.id===selected);
  if(!sub)return `<h1 class="page-title">Mark Attendance</h1><div class="empty">No subjects assigned.</div>`;
  const existing=db.attendance.filter(a=>a.subjectId===selected&&a.date===date);
  return `<h1 class="page-title">Mark Daily Attendance</h1><p class="subtitle">Use the checklist to mark present students.</p>
  <div class="panel"><div class="form-grid"><div><label>Subject</label><select id="subjectSelect" onchange="navigate('mark')">${subs.map(s=>`<option value="${s.id}" ${s.id===selected?"selected":""}>${esc(s.name)}</option>`).join("")}</select></div>
  <div><label>Date</label><input type="date" id="attDate" value="${date}" onchange="navigate('mark')"></div></div></div>
  <div class="panel"><h3>${esc(sub.name)} — Student Checklist</h3>
  <div class="checklist">${db.students.map(st=>{
    const old=existing.find(a=>a.studentId===st.id);
    return `<div class="student-row"><label>${esc(st.roll)} — ${esc(st.name)}</label><label><input type="checkbox" class="attCheck" data-student="${st.id}" ${old?.present?"checked":""}> Present</label></div>`
  }).join("")}</div><br><button class="primary" onclick="saveAttendance('${selected}','${date}')">Save Attendance</button></div>`
}

function saveAttendance(subjectId,date){
  const db=getDB();
  db.attendance=db.attendance.filter(a=>!(a.subjectId===subjectId&&a.date===date));
  document.querySelectorAll(".attCheck").forEach(c=>db.attendance.push({date,subjectId,studentId:c.dataset.student,present:c.checked}));
  saveDB(db);alert("Attendance saved successfully!");navigate("mark");
}

function reports(){
  const db=getDB(), subs=db.subjects.filter(s=>s.facultyId===session.id);
  const sid=document.querySelector("#reportSubject")?.value||subs[0]?.id;
  const sub=db.subjects.find(s=>s.id===sid);
  if(!sub)return `<h1 class="page-title">Class Report</h1><div class="empty">No subjects assigned.</div>`;
  return `<h1 class="page-title">Class-wise Attendance Report</h1><p class="subtitle">Monitor students below the 75% requirement.</p>
  <div class="panel"><label>Subject</label><select id="reportSubject" onchange="navigate('reports')">${subs.map(s=>`<option value="${s.id}" ${s.id===sid?"selected":""}>${esc(s.name)}</option>`).join("")}</select></div>
  <div class="panel"><div class="table-wrap"><table><tr><th>Roll No</th><th>Student</th><th>Attendance</th><th>Status</th></tr>${db.students.map(st=>{let p=pct(db,st.id,sid);return `<tr><td>${st.roll}</td><td>${esc(st.name)}</td><td>${p}%</td><td><span class="badge ${p<75?"low":"ok"}">${p<75?"Warning":"Safe"}</span></td></tr>`}).join("")}</table></div></div>`
}

function subjectsPage(){
  const db=getDB(), faculty=db.users.filter(u=>u.role==="faculty");
  return `<h1 class="page-title">Subjects & Classes</h1><p class="subtitle">Admin can add subjects and assign faculty.</p>
  <div class="panel"><h3>Add Subject</h3><div class="form-grid">
  <div><label>Subject Name</label><input id="newSubName" placeholder="e.g. Machine Learning"></div>
  <div><label>Subject Code</label><input id="newSubCode" placeholder="ML301"></div>
  <div><label>Class</label><input id="newClass" value="B.Tech AI - II Year"></div>
  <div><label>Faculty</label><select id="newFaculty">${faculty.map(f=>`<option value="${f.id}">${esc(f.name)}</option>`).join("")}</select></div>
  </div><br><button class="primary" onclick="addSubject()">Add Subject</button></div>
  <div class="panel"><h3>Existing Subjects</h3><div class="table-wrap"><table><tr><th>Name</th><th>Code</th><th>Class</th><th>Faculty</th></tr>${db.subjects.map(s=>`<tr><td>${esc(s.name)}</td><td>${s.code}</td><td>${esc(s.className)}</td><td>${esc(faculty.find(f=>f.id===s.facultyId)?.name||"Unassigned")}</td></tr>`).join("")}</table></div></div>`
}

function addSubject(){
  const db=getDB(); const name=document.querySelector("#newSubName").value.trim(), code=document.querySelector("#newSubCode").value.trim(), className=document.querySelector("#newClass").value.trim(), facultyId=document.querySelector("#newFaculty").value;
  if(!name||!code||!className)return alert("Please fill all fields.");
  db.subjects.push({id:uid("SUB"),name,code,className,facultyId});saveDB(db);alert("Subject added.");navigate("subjects");
}

function usersPage(){
  const db=getDB();
  return `<h1 class="page-title">Users</h1><p class="subtitle">Manage students and faculty accounts.</p>
  <div class="panel"><h3>Add Student</h3><div class="form-grid"><div><label>Name</label><input id="stuName"></div><div><label>Roll Number</label><input id="stuRoll"></div><div><label>Email</label><input id="stuEmail"></div><div><label>Password</label><input id="stuPass" value="student123"></div></div><br><button class="primary" onclick="addStudent()">Add Student</button></div>
  <div class="panel"><h3>Registered Users</h3><div class="table-wrap"><table><tr><th>Name</th><th>Email</th><th>Role</th></tr>${db.users.map(u=>`<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${u.role}</td></tr>`).join("")}</table></div></div>`
}

function addStudent(){
  const db=getDB();const name=document.querySelector("#stuName").value.trim(),roll=document.querySelector("#stuRoll").value.trim(),email=document.querySelector("#stuEmail").value.trim(),password=document.querySelector("#stuPass").value;
  if(!name||!roll||!email||!password)return alert("Please fill all fields.");
  const id=uid("S");db.students.push({id,name,roll,className:"B.Tech AI - II Year"});db.users.push({id,name,email,password,role:"student"});saveDB(db);alert("Student added.");navigate("users");
}

function attendancePage(){
  const db=getDB(), me=db.students.find(s=>s.id===session.id);
  return studentDashboard(db);
}

function render(){
  const app=document.querySelector("#app");
  if(!session){app.innerHTML=loginPage();return}
  const page=location.hash.replace("#","")||"dashboard";
  let body= page==="dashboard"?dashboard()
    :page==="attendance"&&session.role==="student"?attendancePage()
    :page==="mark"&&session.role==="faculty"?markAttendance()
    :page==="reports"&&session.role==="faculty"?reports()
    :page==="subjects"&&session.role==="admin"?subjectsPage()
    :page==="users"&&session.role==="admin"?usersPage()
    :dashboard();
  app.innerHTML=shell(body,page);
}
window.addEventListener("hashchange",render);
render();
